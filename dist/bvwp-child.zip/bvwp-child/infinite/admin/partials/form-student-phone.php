<?php extract($args); ?>

<div>
	<label for="primary_phone" class="font-semibold text-secondary">Phone #</label>
	<input type="text" id="primary_phone" name="updates[primary_phone]" placeholder="Phone #" class="w-full" value="<?php echo $data['primary_phone']; ?>">
</div>